<section class="modal">
    <div class="modal-border">
        <ul class="modal-ul">
            <li class="modal-li">
                <a class="link" href="/Linux/ArchGuide">Arch Linux Install Guide</a>
                <br />
                <a class="link" href="/Linux/PerformanceGuide">Performance Tweaks Guide</a>
                <br />
                <a class="link" href="/Linux/SecurityGuide">Linux Security Guide</a>
                <br />
                <a class="link" href="/Linux/Gentoomusl">My experience on Gentoo musl</a>
                <br />
                <a class="link" href="/Linux/GentooGlibctomusl">Gentoo Glibc to musl easy</a>
            </li>
        </ul>
    </div>
</section>