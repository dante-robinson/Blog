<section class="modal">
    <div class="modal-border">
        <ul class="modal-ul">
            <li class="modal-li">
                <a class="link" href="/BSD/4MonthsofBSD">4 Months of BSD</a>
            </li>
        </ul>
    </div>
</section>
