<section class="modal">
    <div class="modal-border">
        <ul class="modal-ul">
            <li class="modal-li">
                <a class=" link" href="/Crypto/XRPXLMScam">XRP & XLM The biggest scams</a>
                <br />
                <a class="link" href="/Crypto/CommunistCBDC">Communist CBDCs</a>
            </li>
        </ul>
    </div>
</section>