<footer>
    <div>
        <a class="footer-link" target="_blank" rel="noopener noreferrer" href="https://cointr.ee/dante_robinson">
            <i class="fa-brands fa-bitcoin"></i>
            CoinTree
        </a>
    </div>

    <div>
        <a class="footer-link" target="_blank" rel="noopener noreferrer" href="https://github.com/dante-robinson/Blog">
            Source Code on Github
            <i class="fa-brands fa-github"></i>
        </a>
    </div>
</footer>