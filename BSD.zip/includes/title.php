<div class="container">
    <div>
        <a class="title" href="/">Dante's Blog</a>
    </div>
</div>