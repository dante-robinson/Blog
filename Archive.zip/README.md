This blog is fully in HTML+CSS now. If you are looking for the older versions containing PHP or the NextJS version they are locate in this same repo as branches.

To edit the code it's as simple as just editing the html and css in your code editor and loading the file in your browser to view the changes.
